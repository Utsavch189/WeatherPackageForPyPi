from setuptools import setup
setup(
    name="weather_utsav",
    version="1.0.0",
    description="This is a Weather Provider.",
    author="Utsav",
    packages=['weather_utsav'],
    install_requires=['requests']
)
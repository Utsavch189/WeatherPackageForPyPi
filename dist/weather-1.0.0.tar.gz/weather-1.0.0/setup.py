from setuptools import setup
setup(
    name="weather",
    version="1.0.0",
    description="This is a Weather Provider.",
    author="Utsav",
    packages=['weather'],
    install_requires=['requests']
)